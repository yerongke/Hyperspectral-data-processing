function result=fitt(x,N)

%f1   [-100,100]
%{
sum=0;
for j=1:N
    sum=sum+x(j)^2;
end
result=sum;
%}

%f2   [-10,10]
%{
sum1=0;
sum2=1;
for j=1:N
    sum1=sum1+ abs(x(j));
    sum2=sum2* abs(x(j));
end
result=sum1+sum2;
%}


%f3   [-100,100]
%{
sum1=0;
 sum2=0;
 for i=1:N
 for j=1:i
    sum1=sum1+x(j);
 end
 sum2=sum2+sum1^2;
 end
result=sum2;
%}

%f4  [-100,100]

%result=max(abs(x));

%f5  [-100,100]
%
sum=0;
for j=1:N
    sum=sum+(floor(x(j)+0.5))^2;
end
    result=sum;
 %}  
    
    
%f6  [-1.28,1.28]
%{
sum=0;
for j=1:N
    sum=sum+j*x(j)^4;
end
result=sum+rand;
%}
 

%f7   [-100,100]
%{
su=0;
for j=1:N
    su=su+(x(j)-pi)^2;
end
sum=1;
for i=1:N
sum=sum*cos(x(i));
end
result=-(sum*exp(-su));
%}
 



%f8   [-1,1]
%{
sum=0;
for i=1:N
sum=sum+(abs(x(i)))^(i+1);
end
result=sum;
%}


%f9   [-5,5]
%{
sum1=0;
sum2=0;
for i=1:N-1
    sum2=(x(i))^2+(x(i+1))^2+0.5*x(i)*x(i+1);
    sum1=sum1+exp(-sum2/8)*cos(4*abs(sum2));
end
result=-sum1;
%}


%f10   [-10,10]
%{
sum1=0;
sum2=1;
for i=1:N
    sum1=sum1+(sin(x(i)))^2;
    sum2=sum2*exp(-(x(i)^2));
end
result=1+sum1-0.1*sum2;

%}



%f11   [-5.12,5.12]
%{
sum=0;
for j=1:N
    sum=sum+(x(j)^2-10*cos(2*pi*x(j))+10);
end
result=sum;
%}


%f12  [-32,32]
%{
sum1=0;
sum2=0;
for j=1:N
    sum1=sum1+x(j)^2;
    sum2=sum2+cos(2*pi*x(j));
end
result=-20*exp(-0.2*(sum1/N)^0.5)-exp(sum2/N)+20+exp(1);
%}

%f13   [-600,600]
%{
sum1=0;
sum2=1;
for j=1:N
    sum1=sum1+x(j)^2;
   sum2=sum2*cos(x(j)/((j)^0.5));
end
result=sum1/4000-sum2+1;
%}
